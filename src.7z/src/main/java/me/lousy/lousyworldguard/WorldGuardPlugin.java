package me.lousy.lousyworldguard;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class WorldGuardPlugin extends JavaPlugin implements Listener {

    private Location worldGuard1;
    private Location worldGuard2;

    @Override
    public void onEnable() {
        // Register events
        getServer().getPluginManager().registerEvents(this, this);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player) sender;

            if (cmd.getName().equalsIgnoreCase("worldguard1")) {
                worldGuard1 = player.getLocation();
                player.sendMessage("WorldGuard1 set at " + worldGuard1.toString());
            } else if (cmd.getName().equalsIgnoreCase("worldguard2")) {
                worldGuard2 = player.getLocation();
                player.sendMessage("WorldGuard2 set at " + worldGuard2.toString());
            }
        }

        return true;
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (!canBreak(player, event.getBlock().getLocation())) {
            event.setCancelled(true);
            player.sendMessage("You can't break blocks here!");
        }
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        if (!canPlace(player, event.getBlock().getLocation())) {
            event.setCancelled(true);
            player.sendMessage("You can't place blocks here!");
        }
    }

    private boolean canBreak(Player player, Location location) {
        return isInsideWorldGuardRegion(location);
    }

    private boolean canPlace(Player player, Location location) {
        return isInsideWorldGuardRegion(location);
    }

    private boolean isInsideWorldGuardRegion(Location location) {
        if (worldGuard1 == null || worldGuard2 == null) return true;

        World world = location.getWorld();
        double x = location.getX();
        double y = location.getY();
        double z = location.getZ();

        double minX = Math.min(worldGuard1.getX(), worldGuard2.getX());
        double minY = Math.min(worldGuard1.getY(), worldGuard2.getY());
        double minZ = Math.min(worldGuard1.getZ(), worldGuard2.getZ());

        double maxX = Math.max(worldGuard1.getX(), worldGuard2.getX());
        double maxY = Math.max(worldGuard1.getY(), worldGuard2.getY());
        double maxZ = Math.max(worldGuard1.getZ(), worldGuard2.getZ());

        return x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
    }
}
